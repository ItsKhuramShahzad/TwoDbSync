﻿using Dotmim.Sync;
using Dotmim.Sync.SqlServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SyncDbs
{
    public class Class1
    {

      public  async void Sync() {
            // Sql Server provider, the "server" or "hub".
            SqlSyncProvider serverProvider = new SqlSyncProvider(
               @"Data Source=.,1433\SQLEXPRESS;Initial Catalog=db2;Integrated Security=true;");

            // Sqlite Client provider acting as the "client"
            SqlSyncProvider clientProvider = new SqlSyncProvider(
               @"Data Source=.,1433\SQLEXPRESS;Initial Catalog=db1;Integrated Security=true;");

            // Tables involved in the sync process:
            var setup = new SyncSetup("User");

            // Sync agent
            SyncAgent agent = new SyncAgent(clientProvider, serverProvider);

            do
            {
                var result = await agent.SynchronizeAsync(setup);
                Console.WriteLine(result);

            } while (Console.ReadKey().Key != ConsoleKey.Escape);

        }
    }
}
