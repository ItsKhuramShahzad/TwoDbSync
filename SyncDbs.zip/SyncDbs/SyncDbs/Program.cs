﻿using Dotmim.Sync;
using Dotmim.Sync.SqlServer;
using Microsoft.Data.SqlClient;

namespace SyncDbs
{

    class Program
    {
        static async Task Main(string[] args)
        {
            try
            {

                SqlConnection sQlConnection = new SqlConnection(@"Server=.,1433\SQLEXPRESSS; USER ID=Anjum; PASSWORD=Anjum; Initial Catalog=db2;");
                sQlConnection.Open();
                if (sQlConnection.State== System.Data.ConnectionState.Open)
                    Console.WriteLine("Connection success");
                else
                {
                    Console.WriteLine("Connection failed");
                }
            
                SqlSyncProvider serverProvider = new SqlSyncProvider(
                   @"Server=.,1433\SQLEXPRESSS;USER ID=Anjum; PASSWORD=Anjum;  Initial Catalog=db2;");

                // Sqlite Client provider acting as the "client"
                SqlSyncProvider clientProvider = new SqlSyncProvider(
                   @"Server=.,1433\SQLEXPRESSS;USER ID=Anjum; PASSWORD=Anjum;  Initial Catalog=db1;");

                // Tables involved in the sync process:
                var setup = new SyncSetup("User", "Item");

                // Sync agent
               SyncAgent agent = new SyncAgent(serverProvider, clientProvider );
              // SyncAgent agent = new SyncAgent(clientProvider,serverProvider);

                do
                {
                    var result = await agent.SynchronizeAsync(setup);
                    Console.WriteLine(result);

                } while (Console.ReadKey().Key != ConsoleKey.Escape);

                Console.Read();
            }
            catch (Exception ex) { Console.WriteLine(ex.ToString()); }
        }

        async void Sync()
        {
            // Sql Server provider, the "server" or "hub".
            SqlSyncProvider serverProvider = new SqlSyncProvider(
               @"Data Source=.,1433\SQLEXPRESS;Initial Catalog=db2;Integrated Security=true;");

            // Sqlite Client provider acting as the "client"
            SqlSyncProvider clientProvider = new SqlSyncProvider(
               @"Data Source=.,1433\SQLEXPRESS;Initial Catalog=db1;Integrated Security=true;");

            // Tables involved in the sync process:
            var setup = new SyncSetup("User");

            // Sync agent
            SyncAgent agent = new SyncAgent(clientProvider, serverProvider);

            do
            {
                var result = await agent.SynchronizeAsync(setup);
                Console.WriteLine(result);

            } while (Console.ReadKey().Key != ConsoleKey.Escape);

        }
    }

}